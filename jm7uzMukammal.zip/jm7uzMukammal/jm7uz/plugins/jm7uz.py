import asyncio
import time

from telethon import events

async def init(bot):
    @bot.on(events.NewMessage(pattern=r'\.jm'))
    async def handler3(event):
        await event.edit('🐼J')
        time.sleep(0.7)
        await event.edit('🐼J🐼M')
        time.sleep(0.7)
        await event.edit('🐼J🐼M🐼7')
        time.sleep(0.7)
        await event.edit('🐼J🐼M🐼7🐼U')
        time.sleep(0.7)
        await event.edit('🐼J🐼M🌹7🐼u🐼z')
        time.sleep(0.7)
        await event.edit(f"""🐼JM7UZ t.me/Jm7UzBot""")