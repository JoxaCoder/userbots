import asyncio
from telethon.sync import TelegramClient, events
import time
from jm7uz.jm import main
print("bot ishladi")

if __name__ == '__main__':
    asyncio.run(main())
