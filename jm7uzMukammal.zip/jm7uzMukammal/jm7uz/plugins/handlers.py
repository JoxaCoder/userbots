from telethon import events


#async def init(bot):
#    @bot.on(events.Raw)
#    async def handler(update):
#        # Print all incoming updates
#        print(update.stringify())