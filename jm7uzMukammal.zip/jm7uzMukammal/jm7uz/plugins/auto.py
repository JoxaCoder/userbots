import asyncio
import time

from telethon import events

async def init(bot):
    @bot.on(events.NewMessage(pattern='(?i)Assalomu.+', func=lambda e: e.is_private))
    async def alik_ol1(event):
        await event.reply('🤖Va Alaykum Assalom Va Rohmatullohi va Barokatuh!')


    @bot.on(events.NewMessage(pattern='(?i)salo.+', func=lambda e: e.is_private))
    async def alik_ol2(event):
        await event.reply('🤖Va Alaykum Assalom Va Rohmatullohi va Barokatuh!')
