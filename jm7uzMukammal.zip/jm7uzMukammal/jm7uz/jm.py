import asyncio
import os
import sys
import time
from telethon import TelegramClient
from telethon.sessions import StringSession
S_S = ""
API_ID = 146005
API_HASH = "a9fc32cb850af8cd610a3e605bc6c909"
TOKEN = "BOT_TOKENI_YOZING"


try:
    import plugins
except ImportError:
    try:
        from . import plugins
    except ImportError:
        print('Pluginlarni yuklay olmadim plugin yo\'q yoki path hato berilgan?', file=sys.stderr)
        exit(1)

async def main():
    bot = TelegramClient(StringSession(S_S), API_ID, API_HASH)
    await bot.start(bot_token=TOKEN)

    try:
        await plugins.init(bot)
        await bot.run_until_disconnected()
    finally:
        await bot.disconnect()


if __name__ == '__main__':
    asyncio.run(main())