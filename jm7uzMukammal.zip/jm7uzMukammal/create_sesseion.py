from telethon.sync import TelegramClient
from telethon.sessions import StringSession

API_ID = 146005
API_HASH = "a9fc32cb850af8cd610a3e605bc6c909"


with TelegramClient(StringSession(), API_ID, API_HASH) as client:
    print("jm7uz\n\n\n")
    print(client.session.save())