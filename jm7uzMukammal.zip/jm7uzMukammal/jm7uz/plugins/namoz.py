from telethon import events
import json
import requests


JOY = ""

async def init(bot):
    @bot.on(events.NewMessage(pattern=r"\.namoz(?: |$)(.*)"))
    async def get_adzan(namoz):
        if not namoz.pattern_match.group(1):
            LOCATION = JOY
            if not LOCATION:
                await namoz.edit("`Iltimos Shahar yoki mamlakatni ko'rsating.`")
                return
        else:
            LOCATION = namoz.pattern_match.group(1)

        # url = f'http://muslimsalat.com/{LOCATION}.json?key=bd099c5825cbedb9aa934e255a81a5fc'
        url = f"https://api.pray.zone/v2/times/today.json?city={LOCATION}"
        request = requests.get(url)
        if request.status_code == 500:
            return await namoz.edit(f"**Negadur siz bergan joyni topa olmayabman** `{LOCATION}`")

        parse_jm = json.loads(request.text)

        city = parse_jm["results"]["location"]["city"]
        mintaqa = parse_jm["results"]["location"]["country"]
        joyvaqti = parse_jm["results"]["location"]["timezone"]
        date = parse_jm["results"]["datetime"][0]["date"]["gregorian"]

        tong = parse_jm["results"]["datetime"][0]["times"]["Imsak"]
        quyosh = parse_jm["results"]["datetime"][0]["times"]["Fajr"]
        peshin = parse_jm["results"]["datetime"][0]["times"]["Dhuhr"]
        asr = parse_jm["results"]["datetime"][0]["times"]["Asr"]
        shom = parse_jm["results"]["datetime"][0]["times"]["Maghrib"]
        hufton = parse_jm["results"]["datetime"][0]["times"]["Isha"]

        result = (
            f"**Namoz Vaqtlari**:\n"
            f"📅 `{date} | {joyvaqti}`\n"
            f"🌏 `{city} | {mintaqa}`\n\n"
            f"**Tong :** `{tong}`\n"
            f"**Quyosh :** `{quyosh}`\n"
            f"**Peshin :** `{peshin}`\n"
            f"**Asr :** `{asr}`\n"
            f"**Shom :** `{shom}`\n"
            f"**Hufton :** `{hufton}`\n"
        )

        await namoz.edit(result)