import asyncio
import time
from telethon import events
tgbotusername = "@Jobmenuz_bot"
async def init(bot):
    @bot.on(events.NewMessage(pattern=r'\.start'))
    async def handler3(event):
        await event.edit('start')
        time.sleep(0.4)
        await event.edit('start ishladi')
        time.sleep(0.4)

